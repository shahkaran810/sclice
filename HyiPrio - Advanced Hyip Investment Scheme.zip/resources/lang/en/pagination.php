<?php

return array(
    'next' => 'Next &raquo;The provided password is incorrect',
    'previous' => '&laquo; Previous',
);
