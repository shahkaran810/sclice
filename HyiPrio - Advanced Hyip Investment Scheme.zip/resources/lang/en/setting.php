<?php

return array(
    'add' => 'Add Now',
);
