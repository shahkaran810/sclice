<?php

return array(
    'add' => 'Añadir ahora',
);
