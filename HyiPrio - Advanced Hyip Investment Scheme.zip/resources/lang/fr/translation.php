<?php

return array(
    'key' => 'clé',
);
