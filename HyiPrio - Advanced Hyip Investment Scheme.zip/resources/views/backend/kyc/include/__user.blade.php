<a href="{{ route('admin.user.edit',$id) }}" class="link">{{ safe($username) }}</a>
