<span class="clock"> {{  \Carbon\Carbon::parse($kyc_time)->format('F d Y h:i') }} </span>
