<div class="site-badge {{ $capital_back ? 'success' : 'pending' }}">{{ $capital_back ? 'Yes' : 'No' }}</div>

