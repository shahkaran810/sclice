<?php
namespace SecurionPay\Exception;

class ConnectionException extends \Exception
{
}
