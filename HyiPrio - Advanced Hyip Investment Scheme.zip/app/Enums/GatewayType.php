<?php

namespace App\Enums;

enum GatewayType: string
{
    case Automatic = 'auto';
    case Manual = 'manual';
}
